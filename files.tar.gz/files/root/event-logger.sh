#!/bin/sh

# syslog
logger -t $0 "1=$1 2=$2 3=$3"
